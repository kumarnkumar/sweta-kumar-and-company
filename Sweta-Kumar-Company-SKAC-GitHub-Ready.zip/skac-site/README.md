# Sweta Kumar & Company — SKAC.in

GitHub Pages-ready static website. Includes SEO metadata, canonical URL, sitemap.xml and robots.txt.

GitHub Pages: Settings → Pages → Deploy from branch → main / root. Set custom domain to skac.in and enable Enforce HTTPS after DNS propagation.

DNS apex A records: 185.199.108.153, 185.199.109.153, 185.199.110.153. www CNAME → YOUR-USERNAME.github.io
